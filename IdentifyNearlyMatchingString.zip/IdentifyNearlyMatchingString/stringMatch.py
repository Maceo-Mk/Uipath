import numpy as np
import json
import re

from PIL import Image
import pytesseract
import argparse
import cv2
import os
import io
import sys
import xlsxwriter
import openpyxl
from PIL import Image
import PIL.Image
from pytesseract import image_to_string
import pytesseract
import re

pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe"
# pytesseract.pytesseract.tesseract_cmd=r'D:\\tesseract\\e-Aksharayan Kannada_setup (1).exe'



# def ExtractText(Img):
#
#     # reading text from Image using pytesseract ocr
#     im=Image.open(Img).convert("RGB")
#     result = pytesseract.image_to_string(im,lang='eng')
#
#     # defining an unique filename
#     filePath = 'abc.txt'
#     with open(filePath, 'wb')as f:
        # f.write(result.encode('utf-8'))


def levenshtein_ratio_and_distance(s, t, ratio_calc=False):
    """ levenshtein_ratio_and_distance:
        Calculates levenshtein distance between two strings.
        If ratio_calc = True, the function computes the
        levenshtein distance ratio of similarity between two strings
        For all i and j, distance[i,j] will contain the Levenshtein
        distance between the first i characters of s and the
        first j characters of t
    """
    # Initialize matrix of zeros
    rows = len(s)+1
    cols = len(t)+1
    distance = np.zeros((rows, cols), dtype=int)
    # print(distance)

    # Populate matrix of zeros with the indeces of each character of both strings
    for i in range(1, rows):
        for k in range(1, cols):
            distance[i][0] = i
            distance[0][k] = k
    # print(distance)
    # Iterate over the matrix to compute the cost of deletions,insertions and/or substitutions
    for col in range(1, cols):
        for row in range(1, rows):
            if s[row-1] == t[col-1]:
                # If the characters are the same in the two strings in a given position [i,j] then the cost is 0
                cost = 0
            else:
                # In order to align the results with those of the Python Levenshtein package, if we choose to calculate the ratio
                # the cost of a substitution is 2. If we calculate just distance, then the cost of a substitution is 1.
                if ratio_calc == True:
                    cost = 2
                else:
                    cost = 1
            distance[row][col] = min(distance[row-1][col] + 1,      # Cost of deletions
                                     # Cost of insertions
                                     distance[row][col-1] + 1,
                                     distance[row-1][col-1] + cost)     # Cost of substitutions

    if ratio_calc == True:
        # Computation of the Levenshtein Distance Ratio
        Ratio = ((len(s)+len(t)) - distance[row][col]) / (len(s)+len(t))
        return Ratio
    else:
        # print(distance) # Uncomment if you want to see the matrix showing how the algorithm computes the cost of deletions,
        # insertions and/or substitutions
        # This is the minimum number of edits needed to convert string a to string b
        return " {} edits required".format(distance[row][col])

#
def CheckKeyword(Str1,data_file):
    FinalData = []
    with open(data_file, 'rb')as d:
        data = json.load(d)

    for Str2 in data['AllBoards']:
        Ratio = levenshtein_ratio_and_distance(Str1, Str2, ratio_calc=True)
        result = {
            "keyword": Str2,
            "Ratio": Ratio
        }
        FinalData.append(result)

    Match = max(FinalData, key=lambda x: x['Ratio'])

    return Match
#
# # def Text_file():
#     with open('abc.txt', 'rb')as f1:
#         Str1=f1.readlines()
#         # Str1=Str1.decode()
#         # Str1.strip("\n")
#
#
#     for i in Str1:
#
#         i=i.decode()
#         i=str(i)
#         # print(i)
#         if "Board" in str(i) or "Institute" in i or "Council" in i:
#             print("i",i)
#             return i
#         elif "BOARD" in str(i) or "INSTITUTE" in i or "COUNCIL" in i:
#
#                 print("i",i)
#                 return i
#         else:
#            pass
#
#
#
#
# def Text_file1():
#     regEx = r'(?:\d{1,2}[-/th|st|nd|rd\s]*)?(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)?[a-z\s,.]*(?:\d{1,2}[-/th|st|nd|rd)\s,]*)+(?:\d{2,4})+'
#     with open('abc.txt', 'rb')as f1:
#         Str5=f1.readlines()
#     for i in Str5:
#
#
#         i=i.decode()
#         i=str(i)
#
#         result = re.findall(regEx, i)
#         # print("j",i)
#         if len(result)!=0:
#             for i in result:
#                 if "-" in i :
#
#                     print("result",i)
#                 elif  "/" in i:
#                      print("result",i)
#
#                 elif  "st" in i:
#                     print("result",i)
#
#                 elif  "nd" in i:
#                      print("result",i)
#
#                 elif  "rd" in i:
#                      print("result",i)
#
#                 elif  "th" in i:
#                     print("result",i)

def calling_func(string1,data_file):

    # print("gk",gk)
    result = CheckKeyword(string1,data_file)
    # print(f"{result['keyword']}  --Accuracy {result['Ratio']*100}%")
    return [result['keyword'],str(result['Ratio']*100)+str(" %")]
    # return ( "Accuracy------",str(result['Ratio']*100)+str("%"))
    # print(result['keyword'])





# if __name__ == '__main__':
#     # Str1 = "Board of Hinh SGhqu ans Intermediate Eduu.Bw Uttar anh"
#     # result = CheckKeyword(Str1)
#     # print(f"{result['keyword']}  --Accuracy {result['Ratio']*100}%")
#     # gk=Text_file()
#     # result = CheckKeyword(str(gk))
#     # print(result['keyword'])
#
#     ExtractText("C:\\Users\\BOT mantra\\Documents\\UiPath\\IdentifyRegExPatterns\\Python\\up1.jpg")
#
# kl=calling_func("Board of Niall School ans Intermediate Eduuhﬁon Uttar anh")
# print(kl[0])
